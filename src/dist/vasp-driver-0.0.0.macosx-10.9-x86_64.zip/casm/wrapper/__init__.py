"""Functions used by wrappers"""
from casm.wrapper.misc import jobname

__all__ = [
    'jobname']
